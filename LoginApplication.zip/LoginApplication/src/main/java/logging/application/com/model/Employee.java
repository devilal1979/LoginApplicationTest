package logging.application.com.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="EMPLOYEE")
public class Employee  implements Serializable{
	
	public Employee() {
		
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 6674678839977221202L;
	
	
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="I_EMPLOYEE", unique=true, nullable=false)
	private int iemployee;
	
	
	@Column(name="EMP_ID", length=10)
	private String empid;
	
	@Column(name="EMP_NAME", length=30)
	private String empname;
	
	@Column(name="EMP_ADDRESS", length=50)
	private String empaddress;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_DEPT")
	private DeptLkup deptLkup;
	
	

	public int getIemployee() {
		return iemployee;
	}

	public void setIemployee(int iemployee) {
		this.iemployee = iemployee;
	}

	public String getEmpid() {
		return empid;
	}

	public void setEmpid(String empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public String getEmpaddress() {
		return empaddress;
	}

	public void setEmpaddress(String empaddress) {
		this.empaddress = empaddress;
	}

	public DeptLkup getDeptLkup() {
		return deptLkup;
	}

	public void setDeptLkup(DeptLkup deptLkup) {
		this.deptLkup = deptLkup;
	}
	
	
	
	

}
