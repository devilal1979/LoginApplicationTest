package logging.application.com.ServiceIface;

import java.util.List;

import logging.application.com.model.DepartmentBO;
import logging.application.com.model.DeptLkup;

public interface CommonLookUpServiceIface {
	
	public List<DepartmentBO> getDeptList();

}
