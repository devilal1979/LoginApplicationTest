package com.application.todo.service;

import java.util.List;

import com.application.todo.model.User;

public interface UserMongoDBService {
	
	void saveUser(User user);
	
    User findById(long id);
	
	User findByName(String name);
	
    void updateUser(User user);
	
	void deleteUserById(long id);

	List<User> findAllUsers(); 
	
	void deleteAllUsers();
	
	public boolean isUserExist(User user);
	

}
