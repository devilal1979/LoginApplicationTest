package logging.application.com.ServiceIfaceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import logging.application.com.DaoIface.UserDaoIface;
import logging.application.com.ServiceIface.UserServiceIface;
import logging.application.com.model.User;



@Service
@Transactional(readOnly = true)
public class UserServiceIfaceImpl implements UserServiceIface {
	
	@Autowired
	private UserDaoIface userDaoIface;

	@Transactional(readOnly = true)
	public User getUserByName(String username, String password) {
		// TODO Auto-generated method stub
		return userDaoIface.getUserByName(username, password);
	}
	
	
	
	

}
