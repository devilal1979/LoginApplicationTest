package logging.application.com.managed;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;

import org.springframework.dao.DataAccessException;

import logging.application.com.ServiceIface.UserServiceIface;
import logging.application.com.logger.TestingLogger;
import logging.application.com.model.User;

@ManagedBean(name="userMB")
@RequestScoped
public class LoginUserManagedBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2395080603610819079L;
	
	private static final String SUCCESS = "employee";
	
	private static final String ERROR   = "error";
	
	private String username;
	
	private String password;
	
	 public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@ManagedProperty(value="#{UserServiceIfaceImpl}")
	 UserServiceIface userService;
	 
	 User user;

	public UserServiceIface getUserService() {
		return userService;
	}

	public void setUserService(UserServiceIface userService) {
		this.userService = userService;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	
	
	public String loginUser(){
		
	 try {

		getUserService().getUserByName(getUsername(), getPassword());
		return SUCCESS;
		
	  }catch (DataAccessException e) {
		  TestingLogger.error("errors"+e);
	  }
	 
	   return ERROR;

		
		
	}
	
	public void reset() {
		
		this.username="";
		this.password="";
		
		
	}



	
	

}
