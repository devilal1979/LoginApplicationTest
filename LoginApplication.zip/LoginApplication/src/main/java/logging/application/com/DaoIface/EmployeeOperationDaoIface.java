package logging.application.com.DaoIface;

import java.util.List;

import logging.application.com.model.Employee;

public interface EmployeeOperationDaoIface {
	
	public void addEmployee(Employee emp); 
	
	public void deleteEmployee(Employee emp);
	
	public void updateEmployee(Employee emp);
	
	public List<Employee> getEmployeeList();
	
	public Employee  getEmployee(String empid);
	

}
