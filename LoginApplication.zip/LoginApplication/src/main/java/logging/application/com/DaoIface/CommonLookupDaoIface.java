package logging.application.com.DaoIface;

import java.util.List;

import logging.application.com.model.DeptLkup;

public interface CommonLookupDaoIface {
	
	public List<DeptLkup> getDeptList();

}
