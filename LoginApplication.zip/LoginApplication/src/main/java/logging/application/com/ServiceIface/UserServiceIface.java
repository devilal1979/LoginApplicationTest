package logging.application.com.ServiceIface;

import logging.application.com.model.User;

public interface UserServiceIface {
	
	public User getUserByName(String username,String password);

}
