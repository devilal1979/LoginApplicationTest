package logging.application.com.ServiceIfaceImpl;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import logging.application.com.DaoIface.EmployeeOperationDaoIface;
import logging.application.com.ServiceIface.EmployeeOperationServiceIface;
import logging.application.com.model.Employee;
import logging.application.com.model.EmployeeBO;

@Service
@Transactional(readOnly = true)
public class EmployeeOperationServiceImpl implements EmployeeOperationServiceIface {
	
	@Autowired
	private EmployeeOperationDaoIface employeeOperationDaoIface;
	

	@Transactional(readOnly = false)
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		employeeOperationDaoIface.addEmployee(emp);
		
	}
	@Transactional(readOnly = false)
	public void deleteEmployee(Employee emp) {
		// TODO Auto-generated method stub
		employeeOperationDaoIface.deleteEmployee(emp);
		
	}
	
	@Transactional(readOnly = false)
	public void updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		employeeOperationDaoIface.updateEmployee(emp);
		
	}
	@SuppressWarnings("null")
	@Transactional(readOnly = true)
	public List<EmployeeBO> getEmployeelist() {
		// TODO Auto-generated method stub
		List<EmployeeBO>  employeebolist =new ArrayList<EmployeeBO>();
		List<Employee>  employeelist = employeeOperationDaoIface.getEmployeeList();
		if(employeelist!=null||employeelist.size()>0){
		for(Employee emp:employeelist){
			EmployeeBO bo = new EmployeeBO();
			bo.setEmpid(emp.getEmpid());
			bo.setEmpname(emp.getEmpname());
			bo.setEmpaddress(emp.getEmpaddress());
			bo.setEmpdept(emp.getDeptLkup().getXdept());
			employeebolist.add(bo);
		  }
			
		}
		
		return employeebolist;
	}
	public EmployeeBO getEmployee(String empid) {
		// TODO Auto-generated method stub
		
		Employee emp = employeeOperationDaoIface.getEmployee(empid);
		EmployeeBO  bo = new EmployeeBO();
		bo.setEmpid(emp.getEmpid());
		bo.setEmpname(emp.getEmpname());
		bo.setEmpaddress(emp.getEmpaddress());
		bo.setEmpdept(emp.getDeptLkup().getCdept());
		
		
		return bo;
	}
		
		
	

}
