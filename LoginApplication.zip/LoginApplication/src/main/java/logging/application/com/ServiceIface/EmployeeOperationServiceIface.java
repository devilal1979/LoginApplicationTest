package logging.application.com.ServiceIface;

import java.util.List;

import logging.application.com.model.Employee;
import logging.application.com.model.EmployeeBO;

public interface EmployeeOperationServiceIface {
	
    public void addEmployee(Employee emp); 
	
	public void deleteEmployee(Employee emp);
	
	public void updateEmployee(Employee emp);
	
	public List<EmployeeBO> getEmployeelist();
	
	public EmployeeBO getEmployee(String empid);

}
