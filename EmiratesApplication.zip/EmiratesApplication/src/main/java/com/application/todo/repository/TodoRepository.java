package com.application.todo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.application.todo.entity.UserEntity;;

public interface TodoRepository extends MongoRepository<UserEntity, Long> {
	
	 //List<UserEntity> findAll();
	 
	

}
