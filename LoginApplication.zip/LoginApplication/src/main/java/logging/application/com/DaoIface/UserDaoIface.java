package logging.application.com.DaoIface;

import logging.application.com.model.User;

public interface UserDaoIface {
	
	public User getUserByName(String username,String password);

}
