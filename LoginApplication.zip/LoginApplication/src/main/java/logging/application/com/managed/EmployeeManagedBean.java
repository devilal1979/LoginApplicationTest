package logging.application.com.managed;

import java.io.Serializable;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;

import org.springframework.dao.DataAccessException;

import logging.application.com.ServiceIface.CommonLookUpServiceIface;
import logging.application.com.ServiceIface.EmployeeOperationServiceIface;
import logging.application.com.logger.TestingLogger;
import logging.application.com.model.DepartmentBO;
import logging.application.com.model.DeptLkup;
import logging.application.com.model.Employee;
import logging.application.com.model.EmployeeBO;

@ManagedBean(name="EmployeeMB")
@RequestScoped
public class EmployeeManagedBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8553961027502381908L;
	
	private String empid;
	
	private String empname;
	
	private String  empaddress;
	
	private String dept;
	
	private String msg;
	
    public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	private static final String SUCCESS = "success";
    
    private static final String DELETE = "deleteemployee";
    
    private static final String SAVE = "saveemployee";
	
	private static final String ERROR   = "error";
	
	private static final String UPDATE= "updateemployee";
	
	
	List<DepartmentBO> deprtments;
	
	@ManagedProperty(value="#{CommonLookUpServiceImpl}")
	CommonLookUpServiceIface commonLookUpServiceIface;
	
	@ManagedProperty(value="#{EmployeeOperationServiceImpl}")
	EmployeeOperationServiceIface employeeOperationServiceIface;
	
	List<EmployeeBO>  employeelist;
	
	

	public EmployeeOperationServiceIface getEmployeeOperationServiceIface() {
		return employeeOperationServiceIface;
	}

	public void setEmployeeOperationServiceIface(EmployeeOperationServiceIface employeeOperationServiceIface) {
		this.employeeOperationServiceIface = employeeOperationServiceIface;
	}

	public List<EmployeeBO> getEmployeelist() {
		return employeelist;
	}

	public void setEmployeelist(List<EmployeeBO> employeelist) {
		this.employeelist = employeelist;
	}

	public List<DepartmentBO> getDeprtments() {
		return deprtments;
	}

	public void setDeprtments(List<DepartmentBO> deprtments) {
		this.deprtments = deprtments;
	}

	public CommonLookUpServiceIface getCommonLookUpServiceIface() {
		return commonLookUpServiceIface;
	}

	public void setCommonLookUpServiceIface(CommonLookUpServiceIface commonLookUpServiceIface) {
		this.commonLookUpServiceIface = commonLookUpServiceIface;
	}

	
	
	

	public String getEmpid() {
		return empid;
	}

	public void setEmpid(String empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public String getEmpaddress() {
		return empaddress;
	}

	public void setEmpaddress(String empaddress) {
		this.empaddress = empaddress;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}
	
	public List<DepartmentBO> getDepartments(){
		
		List<DepartmentBO> deprtmentlist =getCommonLookUpServiceIface().getDeptList();
		return deprtmentlist;
		
		
	}
	
	public List<EmployeeBO>  getEmployeeList(){
		
		employeelist = employeeOperationServiceIface.getEmployeelist();
		
		return employeelist;
		
	}
	
	public String  deleteEmployee(String empid){
		
		Employee  emp = new Employee();
		emp.setEmpid(empid);
		try {

			getEmployeeOperationServiceIface().deleteEmployee(emp);
			this.msg="The Employee is Deleted";
			return DELETE;
			
		  }catch (DataAccessException e) {
			  TestingLogger.error("errors"+e);
		  }
		 
		   return ERROR;
		
		
	}
	
	public String addEmployee(){
		
		Employee  emp = new Employee();
		DeptLkup deptLkup = new DeptLkup();
		deptLkup.setCdept(getDept());
		emp.setEmpid(getEmpid());
		emp.setEmpname(getEmpname());
		emp.setEmpaddress(getEmpaddress());
		emp.setDeptLkup(deptLkup);
		try {

			getEmployeeOperationServiceIface().addEmployee(emp);
			this.msg="New Employee Details are Added";
			return SAVE;
			
		  }catch (DataAccessException e) {
			  TestingLogger.error("errors"+e);
		  }
		 
		   return ERROR;
		
		
	}
	
	public String updateEmployeeView(String empid){
		try {
		EmployeeBO bo =getEmployeeOperationServiceIface().getEmployee(empid);
		this.empid=bo.getEmpid();
		this.empname=bo.getEmpname();
		this.empaddress=bo.getEmpaddress();
		this.dept=bo.getEmpdept();
		return SAVE;
		}catch (DataAccessException e) {
			  TestingLogger.error("errors"+e);
		  }
		
		return ERROR;
		
	}
	
	public String updateEmployee(){
		
		Employee  emp = new Employee();
		DeptLkup deptLkup = new DeptLkup();
		deptLkup.setCdept(getDept());
		emp.setEmpid(getEmpid());
		emp.setEmpname(getEmpname());
		emp.setEmpaddress(getEmpaddress());
		emp.setDeptLkup(deptLkup);
		try {
			getEmployeeOperationServiceIface().updateEmployee(emp);
			this.msg="Employee Details are Updated";
			return UPDATE;
		}catch (DataAccessException e) {
			  TestingLogger.error("errors"+e);
		  }
		return ERROR;
		
		
		
	}
	
   public void reset() {
		
		this.empid="";
		this.empname="";
		this.empaddress="";
		this.dept="";
		
		
	}
	
	
	
	
	
	
	
	

}
