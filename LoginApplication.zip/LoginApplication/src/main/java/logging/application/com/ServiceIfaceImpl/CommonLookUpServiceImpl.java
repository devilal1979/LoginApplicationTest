package logging.application.com.ServiceIfaceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import logging.application.com.DaoIface.CommonLookupDaoIface;
import logging.application.com.ServiceIface.CommonLookUpServiceIface;
import logging.application.com.model.DepartmentBO;
import logging.application.com.model.DeptLkup;

@Service
public class CommonLookUpServiceImpl implements CommonLookUpServiceIface  {
	
	@Autowired
	private CommonLookupDaoIface commoniface;

	public List<DepartmentBO> getDeptList() {
		// TODO Auto-generated method stub
		List<DepartmentBO> deptlist = new ArrayList<DepartmentBO>();
		
		List<DeptLkup> lookuplist = commoniface.getDeptList();
		if(lookuplist!=null ||lookuplist.size()>0){
			for (DeptLkup lookup :lookuplist){
				DepartmentBO department = new DepartmentBO();
				department.setDeptcode(lookup.getCdept());
				department.setDeptdesc(lookup.getXdept());
				deptlist.add(department);
			}
		}
		
		
		return deptlist;
	}
	
	

}
