package logging.application.com.DaoIfaceimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import logging.application.com.DaoIface.CommonLookupDaoIface;
import logging.application.com.logger.TestingLogger;
import logging.application.com.model.DeptLkup;

@Repository
public class CommonLookupDaoImpl implements CommonLookupDaoIface {
	
	@Autowired
	private SessionFactory  sessionFactory;

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true, isolation=Isolation.READ_UNCOMMITTED)
	public List<DeptLkup> getDeptList() {
		List<DeptLkup> deptlkupList = null;
		try {
			deptlkupList = sessionFactory.getCurrentSession().createQuery(
					"FROM DeptLkup dept order by dept.idept").list();			
		} catch (Exception e) {
			TestingLogger.error("Error in CommonLookupDaoImpl.getdept(): ", e);
			try {
				throw e;
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		} 
		return deptlkupList;

	}
	
	
	
	
	

}
