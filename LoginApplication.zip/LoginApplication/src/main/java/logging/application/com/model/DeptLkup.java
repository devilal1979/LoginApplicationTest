package logging.application.com.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="DEPT_LKUP")
public class DeptLkup implements Serializable {
	
	public DeptLkup() {
		
	}


	/**
	 * 
	 */
	private static final long serialVersionUID = 4566050699944408066L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="I_DEPT", unique=true, nullable=false)
	private short idept;
	
	@Column(name="C_DEPT", length=3)
	private String cdept;
	
	@Column(name="X_DEPT", length=30)
	private String xdept;
	
	
	@OneToMany(mappedBy="deptlkup")
	private List<Employee> employees;


	public short getIdept() {
		return idept;
	}


	public void setIdept(short idept) {
		this.idept = idept;
	}


	public String getCdept() {
		return cdept;
	}


	public void setCdept(String cdept) {
		this.cdept = cdept;
	}


	public String getXdept() {
		return xdept;
	}


	public void setXdept(String xdept) {
		this.xdept = xdept;
	}


	public List<Employee> getEmployees() {
		return employees;
	}


	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}


	

}
