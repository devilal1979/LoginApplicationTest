package logging.application.com.DaoIfaceimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import logging.application.com.DaoIface.UserDaoIface;
import logging.application.com.model.User;

@Repository
public class UserDoaImpl implements UserDaoIface {
	
	@Autowired
	private SessionFactory  SessionFactory;

	public User getUserByName(String username, String password) {
		// TODO Auto-generated method stub
		@SuppressWarnings("rawtypes")
		List userlist = SessionFactory.getCurrentSession()
											.createQuery("from User where name=?  and password=?")
									        .setParameter(0, username).setParameter(1, password).list();
		return (User)userlist.get(0);
		
	}
	
	
	

}
