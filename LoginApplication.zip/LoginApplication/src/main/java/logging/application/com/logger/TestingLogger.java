package logging.application.com.logger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class TestingLogger {
	
	private static Logger logger = LoggerFactory.getLogger(TestingLogger.class);

	public static void logEntry(String methodName) {
		logger.info("Entering " + methodName + " Method");
	}

	public static void LogExit(String methodName) {
		logger.info("Exiting " + methodName + " Method");
	}

	public static void log(String message) {
		logger.info(message);
	}

	public static void error(String message) {
		logger.error(message);
	}

	public static void error(String message, Throwable t) {
		logger.error(message, t);
	}


}
