package logging.application.com.DaoIfaceimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import logging.application.com.DaoIface.EmployeeOperationDaoIface;
import logging.application.com.logger.TestingLogger;
import logging.application.com.model.Employee;

@Repository
public class EmployeeOperationDaoImpl implements EmployeeOperationDaoIface  {
	
	
	@Autowired
	private SessionFactory  sessionFactory;

	
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().save(emp);
		
	}

	
	public void deleteEmployee(Employee emp) {
		// TODO Auto-generated method stub
		
		sessionFactory.getCurrentSession().delete(emp);
		
		
		
	}

	
	public void updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().merge(emp);
		
	}


	public List<Employee> getEmployeeList() {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<Employee> list = sessionFactory.getCurrentSession().createQuery("from Employee").list();

		
		return list;
	}


	public Employee getEmployee(String empid) {
		// TODO Auto-generated method stub
		
		
		
		try {
			Employee employee = (Employee) sessionFactory.getCurrentSession()
					.createQuery("from EMPLOYEE where empid = :empid")
					.setParameter("empid", empid);
			return employee;
		} catch (Exception e) {
			TestingLogger.error("Error in getEmployee.EMPLOYEE(): ", e);
			try {
				throw e;
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				TestingLogger.error("Error in getEmployee.EMPLOYEE(): ", e);
			}
		}
		return null;
	}

	
    
	
	
	
	
	
	

}
